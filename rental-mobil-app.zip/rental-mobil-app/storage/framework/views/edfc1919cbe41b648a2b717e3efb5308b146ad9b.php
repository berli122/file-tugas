

<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-1\htdocs\rental-mobil-app\resources\views/admin/index.blade.php ENDPATH**/ ?>